#!/bin/bash

# Remove already existing zip files
rm evaluation_script.zip
rm challenge_config.zip

# Create new zip configuration according to the updated code
cd evaluation_script
zip -r ../evaluation_script.zip * -x "*.DS_Store"
cd ..

# Add all necessary files to the challenge_config.zip
zip -r challenge_config.zip * -x "*.DS_Store" -x "evaluation_script/*" -x "*.git" -x "run.sh" -x "code_upload_challenge_evaluation/*" -x "remote_challenge_evaluation/*" -x "worker/*" -x "challenge_data/*" -x "github/*" -x ".github/*" -x "README.md"

# Add CSV files from the annotations directory
cd annotations
zip -ur ../challenge_config.zip *.csv
cd ..

# Create a sample CSV submission file
echo "class3" > submission.csv
echo "0" >> submission.csv
echo "1" >> submission.csv
echo "0" >> submission.csv
echo "1" >> submission.csv
zip -ur challenge_config.zip submission.csv
rm submission.csv
